<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
header('Access-Control-Request-Method: *');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$file_name = ".movies.txt" ;
if(isset($_GET["action"]) && $_GET["action"]=="upload"){
if(isset( $_GET["msg"])){
	echo  "alert : ".$_GET["action"] ;
}
?>
<header>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</header
<body>
<form action="">
	<table style="width:98%;">
		<tr>
			<td style="width:35%;">movie link</td><td><input type='text' name='link' onblur='fill()' style="width:65%;"></td>
		</tr>
		<tr>
			<td>movie name</td><td><input type='text' name='name' style="width:65%;"></td>
		</tr>
		<tr>
			<td>movie img</td><td><input type='text' name='img' style="width:65%;"></td>
		</tr>
		<tr>
			<td colspan=2><center><input type="submit" name="action" value="save" onsubmit="fill()" style="width:300px;"> </center></td>
		</tr>
	</table>
</form>
</body>
<script>
console.log(4545);
function fill(){
	let link = document.getElementsByName("link")[0].value;
	name = link.split("/")[link.split("/").length-1].replace("[EgyBest].","");
	document.getElementsByName("name")[0].value = name;
}
</script>
<?php
}
elseif(isset($_GET["action"]) && $_GET["action"]=="save"){
        $name = $_GET["name"];
        $link    = $_GET["link"];
        $img    = $_GET["img"];
        if($_GET["is_b64"]=="1"){
	        //$name = base64_decode ($name);
	        $link    = base64_decode ($link);
	        $img    = base64_decode ($img);
	}
	$file_data = $name .";|".$link    .";|".$img    ."\n";
	$file_data .= file_get_contents($file_name);
	file_put_contents($file_name, $file_data);
       header("Location: ?action=upload&msg=saved!");
}elseif(isset($_GET["action"]) && $_GET["action"]=="m3u"){
	$file_data = file_get_contents($file_name);
	$file_data_lines = explode ("\n",$file_data);
	echo "#EXTM3U\n";
	foreach($file_data_lines as $line){
		$movie = explode (";|",$line);
		if( count($movie)==3){
			echo "#EXTINF:123  tvg-logo=\"".$movie[2]."\",".$movie[0]."\n";
			echo $movie[1]."\n";
		}
	}
	echo "#EXT-X-ENDLIST";
}elseif(isset($_GET["action"]) && $_GET["action"]=="json"){
	$file_data = file_get_contents($file_name);
	$file_data_lines = explode ("\n",$file_data);
	$list_m= array();
	foreach($file_data_lines as $line){
		$movie = explode (";|",$line);
		if( count($movie)==3){
			$mov = array("img"=>$movie[2],"name"=>$movie[0], "link"=>$movie[1]);
			$list_m[]=$mov;
		}
	}
	echo  json_encode($list_m);
}elseif(isset($_GET["action"]) && $_GET["action"]=="empty"){
	file_put_contents($file_name, "");
	echo "Done";
}elseif(isset($_GET["action"]) && $_GET["action"]=="download"){
	$nbr_tries = 2 ;
	$file_path = $_GET["url"] ;
	$file_name = explode("/",$file_path);
	$file_name = end($file_name);
	$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	$actual_link = explode('.index.php', $_SERVER['REQUEST_URI'], 2);
	$actual_link = $actual_link[0];
	while($nbr_tries>=0){
		$file_data = file_get_contents($file_path);
		echo strlen($file_data) ;
		if (strlen($file_data)>5000){
			file_put_contents($file_name, $file_data);
			echo "<a href='".$actual_link.$file_name."' target='_blank'>".$file_name."</a>";
			break;
		}else{
			echo $file_data;
			echo "<br />"; 
		}
		
		$nbr_tries -= 1;
		sleep(3);
	}
	
}else{
	$file_data = file_get_contents($file_name);
	$file_data_lines = explode ("\n",$file_data);
	echo "<center><a href='?action=empty'> Empty </a><table style='width:300px'>";
	foreach($file_data_lines as $line){
		$movie = explode (";|",$line);
		if( count($movie)==3){
			echo "<tr><td style='width:80%'><a href='".$movie[1]."' target='_blank' style='width:100%;display: block;'><img style='width:80%' src='".$movie[2]."'>".$movie[0]."</a></td><td><a href='?action=download&url=".$movie[1]."' target='_blank'>Save</a></td><tr>";
		}
	}
	echo "</table></center>";
}
