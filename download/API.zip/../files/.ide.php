<?php
$token="imad";
$main_script=".ide.php";
if(!isset($_GET["token"]) || $_GET["token"]!=$token){
	die("token");
}

function str_to_utf8 ($string) { 
    if (mb_detect_encoding($string, 'UTF-8', true) === false) { 
      $string = utf8_encode($string); 
    } 
    return $string; 
}
if(isset($_POST["file_name"] ) && trim($_POST["file_name"])!="" && isset($_POST["file_content"]) && $_POST["file_content"]!="" ){
	
	$file_name    = trim($_POST["file_name"] );
	$file_content = trim($_POST["file_content"] );
        file_put_contents($file_name, str_to_utf8(urldecode(base64_decode($file_content))) );
        die("1");
		
}
if(isset($_POST["file_name"] ) && trim($_POST["file_name"])!=""){
	
	$file_name    = trim($_POST["file_name"] );
	die(file_get_contents($file_name));
}
?>
<html>
<head>
<script src="https://cdn.jsdelivr.net/npm/darkmode-js@1.5.3/lib/darkmode-js.min.js"></script>

<script src="https://www.cdolivet.com/editarea/editarea/edit_area/edit_area_full.js"></script>
	<script language="Javascript" type="text/javascript">
		// initialisation
		editAreaLoader.init({
			id: "file_content"	// id of the textarea to transform	
			,start_highlight: true	
			,font_size: "9"
			,font_family: "verdana, monospace"
			,allow_resize: "y"
			,allow_toggle: false
			,language: "en"
			,syntax: "css"	
			,toolbar: "new_document, save, load, |, charmap, |, search, go_to_line, |, undo, redo, |, select_font, |, change_smooth_selection, highlight, reset_highlight, |, help, |,syntax_selection"
			,load_callback: "my_load"
			,save_callback: "my_save"
			,plugins: "charmap"
			,charmap_default: "arrows"
				
		});
function utf8_to_b64( str ) {
    return window.btoa(encodeURIComponent( str ));
}
		// callback functions
		function my_save(id, content){
			  var xhttp = new XMLHttpRequest();
			  xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
				  document.getElementById("output").innerHTML = this.responseText;
				  if(this.responseText == "1"){
				      var iframe = document.getElementById('frame_file_content');
				      var innerDoc = (iframe.contentDocument) ? iframe.contentDocument : iframe.contentWindow.document;
				      var save_btn = innerDoc .getElementById('save');
				      
				      document.getElementById("output").innerHTML  = "<img src = '"+save_btn.src+"' ></img>";
				      setTimeout(function(){
					      var iframe = document.getElementById('frame_file_content');
					      var innerDoc = (iframe.contentDocument) ? iframe.contentDocument : iframe.contentWindow.document;
					      var save_btn = innerDoc .getElementById('save');
					      
					      document.getElementById("output").innerHTML  = "";
				      },2000);
				  }
				}
			  };
  
			console.log(utf8_to_b64(content));
			const file_name = encodeURI(document.getElementById("file_name").value);
			xhttp.open("POST", "<?php echo $main_script; ?>?token=imad", true);
			xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			xhttp.send("file_name="+file_name+"&file_content="+utf8_to_b64(content) );
			//alert("Here is the content of the EditArea '"+ id +"' as received by the save callback function:\n"+content+(typeof content));
		}
		function select_syntax_lang(){
                   const file_name = encodeURI(document.getElementById("file_name").value);
		    var iframe = document.getElementById('frame_file_content');
		    var innerDoc = (iframe.contentDocument) ? iframe.contentDocument : iframe.contentWindow.document;
		    var choices = innerDoc .getElementById('syntax_selection');
                    const file_ext = file_name .split(".")[file_name .split(".").length-1] ;
		    for(let i=0;i<choices .length;i++){
		        if( choices [i].value == file_ext  ){
		            choices [i].selected = true;
		            
		        }
		    }
		    choices .fireEvent("onchange");
		}
		function my_load(id){
			  var xhttp = new XMLHttpRequest();
			  xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
				  //document.getElementById("output").innerHTML = this.responseText;
				  editAreaLoader.setValue(id, this.responseText);
				  select_syntax_lang();
				}
			  };
  
			console.log(utf8_to_b64(content));
			const file_name = encodeURI(document.getElementById("file_name").value);
			xhttp.open("POST", "<?php echo $main_script; ?>?token=<?php echo $token ?>", true);
			xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			xhttp.send("file_name="+file_name );
			
		}
		
		function test_setSelectionRange(id){
			editAreaLoader.setSelectionRange(id, 100, 150);
		}
		
		function test_getSelectionRange(id){
			var sel =editAreaLoader.getSelectionRange(id);
			alert("start: "+sel["start"]+"\nend: "+sel["end"]); 
		}
		
		function test_setSelectedText(id){
			text= "[REPLACED SELECTION]"; 
			editAreaLoader.setSelectedText(id, text);
		}
		
		function test_getSelectedText(id){
			alert(editAreaLoader.getSelectedText(id)); 
		}
		
		function editAreaLoaded(id){
			if(id=="example_2")
			{
				open_file1();
				open_file2();
			}
		}
		
		function open_file1()
		{
			var new_file= {id: "to\\ é # € to", text: "$authors= array();\n$news= array();", syntax: 'php', title: 'beautiful title'};
			editAreaLoader.openFile('example_2', new_file);
		}
		
		function open_file2()
		{
			var new_file= {id: "Filename", text: "<a href=\"toto\">\n\tbouh\n</a>\n<!-- it's a comment -->", syntax: 'html'};
			editAreaLoader.openFile('example_2', new_file);
		}
		
		function close_file1()
		{
			editAreaLoader.closeFile('example_2', "to\\ é # € to");
		}
		
		function toogle_editable(id)
		{
			editAreaLoader.execCommand(id, 'set_editable', !editAreaLoader.execCommand(id, 'is_editable'));
		}
	
	</script>
	</head>
<body>
<script>



(function() {
var options = {
  bottom: '64px', // default: '32px'
  right: '32px', // default: '32px'
  left: 'unset', // default: 'unset'
  time: '0.5s', // default: '0.3s'
  mixColor: '#fff', // default: '#fff'
  backgroundColor: '#fff',  // default: '#fff'
  buttonColorDark: '#100f2c',  // default: '#100f2c'
  buttonColorLight: '#fff', // default: '#fff'
  saveInCookies: true, // default: true,
  label: '🌓', // default: ''
  autoMatchOsTheme: true // default: true
};
const darkmode = new Darkmode(options);
darkmode.showWidget();
})();

</script>

<div>
<input type="text" name="file_name" id="file_name" value="" />
<span id="output"></span>
</div>

<!-- Create the editor container -->
<textarea id="file_content" style="height: 80%; width: 100%;" name="file_content">
</textarea
<!-- Initialize Quill editor -->
</body>
</html>