<?php 
header('Access-Control-Allow-Origin: *');
header('Content-Type: text/html; charset=utf-8');
ini_set('default_charset','UTF-8'); 



$url=$_GET['url'];
foreach($_GET as $k=>$v){  
	if($k=="url") {continue;}
	$url.='&'.$k.'='.$v;
} 

$content = file_get_contents($url);

if( isset($_GET['arabic']) ) {
	$content = iconv('cp1256', 'utf-8', $content ); 
}

echo $content ;
