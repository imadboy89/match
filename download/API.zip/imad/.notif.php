<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: x-csrftoken');

$title = $_GET["title"];
$body= $_GET["body"];
//echo $_GET["title"].$_GET["body"];
//exec("curl -H 'Content-Type: application/json' \"https://webhooks.mongodb-stitch.com/api/client/v2.0/app/ba9al-xpsly/service/webhook/incoming_webhook/notif_out?title=".$title."&body=".$body."\" ");
$url = "https://webhooks.mongodb-stitch.com/api/client/v2.0/app/ba9al-xpsly/service/webhook/incoming_webhook/notif_out?title=".urlencode($title)."&body=".urlencode($body) ;
//echo  $url  ."<br/>";
echo file_get_contents( $url );
?>