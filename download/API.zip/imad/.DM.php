<?php 
$vidID= isset($_GET['vidID']) ? $_GET['vidID'] : "k6jUJ2IpSnKUIuwsAy4";
?>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style=' background-color: #000;'>
<div id="player-dailymotion" style='max-width: 100%;max-width: "100%";'></div>
<br/>
<!-- <button type="button" onclick="play_fn()">Play</button>-->
<!-- <button type="button" onclick="play_pause()">Pause</button>-->

<script src="https://api.dmcdn.net/all.js"></script>
<script>
var player = DM.player(document.getElementById('player-dailymotion'), {
        video: '<?php echo $vidID;?>',
        width: '100%',
        height: '100%',
    });
    

function play_fn(){
    player.play();
}

function play_pause(){
 player.pause();
}
</script>

</body>
</html>