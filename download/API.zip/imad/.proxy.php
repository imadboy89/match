<?php 
$ua = strtolower($_SERVER['HTTP_USER_AGENT'] );
if(strpos($ua, "yacine/") !== false){
    header('HTTP/1.0 403 Forbidden');
    die( 'You are forbidden!');
}
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
header('Access-Control-Request-Method: *');

header('Content-Type: text/html; charset=utf-8');
ini_set('default_charset','UTF-8'); 

$url=$_GET['url'];
foreach($_GET as $k=>$v){  
	if($k=="url") {continue;}
	$url.='&'.$k.'='.$v;
} 


// create curl resource
$ch = curl_init();

// set url
curl_setopt($ch, CURLOPT_URL, $url);

//return the transfer as a string
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

// $output contains the output string
$content = curl_exec($ch);

// close curl resource to free up system resources
curl_close($ch);      
        
        


//$content = file_get_contents($url);
if( isset($_GET['arabic']) ) {
	$content = iconv('cp1256', 'utf-8', $content ); 

}

echo $content ;
//echo "__".$_SERVER['HTTP_USER_AGENT']."__" ;
