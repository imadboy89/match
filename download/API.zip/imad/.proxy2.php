<?php 
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
header('Access-Control-Request-Method: *');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$url=$_GET['url'];
$post=array();
foreach($_GET as $k=>$v){
	if($k=='url'){continue;}    
	$post[$k]=$v;
} 
$headers_ = apache_request_headers();
$is_post_count=0;
if (isset($_POST)){
	foreach($_POST as $k=>$v){
		$is_post_count+=1;
		if($k=='url'){continue;}    
		$post[$k]=$v;
	} 
}
$headers = 'Content-Type: application/x-www-form-urlencoded' ;
$headers .= "\r\n".'User-Agent: Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36' ;
$headers .= "\r\n".'Accept: */*';
if (isset($headers_["Device-Token"])){

	$headers.="\r\n"."device-token: ".$headers_["Device-Token"];
}
$method = $is_post_count>0 ? "POST" :"GET" ;
$post = http_build_query($post);
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

$headers.="\r\n"."X-Forwarded-For : ".$ip;
//echo $method ;
$ops = 	array(
	'http' => array(
			'method'  =>  $method ,
			'header'  => $headers,
			'content' => $post
		),
    "ssl"=>array(
        "verify_peer"=>false,
        "verify_peer_name"=>false,
    )
		
		) ;
//print_r($ops);

$context = stream_context_create($ops);
echo file_get_contents($url, false, $context);
exit();

